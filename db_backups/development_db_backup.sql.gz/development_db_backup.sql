-- MySQL dump 10.13  Distrib 5.5.28, for osx10.8 (i386)
--
-- Host: localhost    Database: iim_development
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airline_rights_countries`
--

DROP TABLE IF EXISTS `airline_rights_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airline_rights_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airline_rights_countries`
--

LOCK TABLES `airline_rights_countries` WRITE;
/*!40000 ALTER TABLE `airline_rights_countries` DISABLE KEYS */;
INSERT INTO `airline_rights_countries` VALUES (1,'Great Britain','2013-03-05 14:15:51','2013-03-05 14:18:15'),(2,'Macedonia','2013-03-05 14:17:03','2013-03-05 14:17:03'),(3,'Singapore','2013-03-05 14:27:23','2013-03-05 14:27:23');
/*!40000 ALTER TABLE `airline_rights_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `airline_rights_countries_movies`
--

DROP TABLE IF EXISTS `airline_rights_countries_movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airline_rights_countries_movies` (
  `airline_rights_country_id` int(11) DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airline_rights_countries_movies`
--

LOCK TABLES `airline_rights_countries_movies` WRITE;
/*!40000 ALTER TABLE `airline_rights_countries_movies` DISABLE KEYS */;
/*!40000 ALTER TABLE `airline_rights_countries_movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `airlines`
--

DROP TABLE IF EXISTS `airlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airlines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airlines`
--

LOCK TABLES `airlines` WRITE;
/*!40000 ALTER TABLE `airlines` DISABLE KEYS */;
INSERT INTO `airlines` VALUES (1,'MAT','mat','2013-02-14 20:52:53','2013-02-14 20:52:53'),(2,'MAT','mat','2013-02-14 20:57:01','2013-02-14 20:57:01'),(3,'MAT','mat','2013-02-14 21:05:04','2013-02-14 21:05:04'),(4,'MAT','mat','2013-02-14 21:08:25','2013-02-14 21:08:25'),(5,'MAT','mat','2013-02-14 21:08:39','2013-02-14 21:08:39'),(6,'MAT2','mat2','2013-02-14 21:09:44','2013-02-14 21:09:44'),(8,'test','test','2013-02-14 21:57:11','2013-02-14 21:57:11'),(9,'test2','test','2013-02-14 22:12:31','2013-02-14 22:12:31'),(10,'test2','test','2013-02-14 22:13:10','2013-02-14 22:13:10'),(11,'test3','test3','2013-02-14 22:13:21','2013-02-14 22:13:21'),(12,'test3','test3','2013-02-14 22:13:50','2013-02-14 22:13:50'),(13,'test3','test3','2013-02-14 22:13:51','2013-02-14 22:13:51'),(14,'test3','test3','2013-02-14 22:13:51','2013-02-14 22:13:51'),(15,'test3','test3','2013-02-14 22:13:51','2013-02-14 22:13:51'),(18,'sadfdsf','fdsff','2013-02-14 22:22:28','2013-02-14 22:22:28'),(19,'sadfdsf','fdsff','2013-02-14 22:22:29','2013-02-14 22:22:29'),(20,'sadfdsf','fdsff','2013-02-14 22:22:29','2013-02-14 22:22:29'),(21,'sadfs','sdfsf','2013-02-14 22:29:10','2013-02-14 22:29:10'),(22,'sdfsdf','sdfsdf','2013-02-14 22:30:27','2013-02-14 22:30:27'),(23,'OGI','bla','2013-02-14 22:30:37','2013-02-14 22:30:37'),(24,'qw','qw','2013-02-14 22:33:42','2013-02-14 22:33:42'),(27,'New','Airline','2013-02-25 13:24:55','2013-02-25 13:24:55');
/*!40000 ALTER TABLE `airlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_playlist_items`
--

DROP TABLE IF EXISTS `album_playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album_playlist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_playlist_id` int(11) DEFAULT NULL,
  `album_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_playlist_items`
--

LOCK TABLES `album_playlist_items` WRITE;
/*!40000 ALTER TABLE `album_playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `album_playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_playlists`
--

DROP TABLE IF EXISTS `album_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_playlist_code` varchar(255) DEFAULT NULL,
  `airline_id` int(11) DEFAULT NULL,
  `in_out` varchar(255) DEFAULT NULL,
  `start_playdate` date DEFAULT NULL,
  `end_playdate` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `locked` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_playlists`
--

LOCK TABLES `album_playlists` WRITE;
/*!40000 ALTER TABLE `album_playlists` DISABLE KEYS */;
INSERT INTO `album_playlists` VALUES (1,'CI0513 S3000/eX2 AOD',1,'Inbound','2010-03-01','2015-03-01',1,0,'2013-03-08 16:34:48','2013-03-08 16:34:48');
/*!40000 ALTER TABLE `album_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_services`
--

DROP TABLE IF EXISTS `album_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_services`
--

LOCK TABLES `album_services` WRITE;
/*!40000 ALTER TABLE `album_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `album_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_id` int(11) DEFAULT NULL,
  `title_original` varchar(255) DEFAULT NULL,
  `title_english` varchar(255) DEFAULT NULL,
  `artwork` varchar(255) DEFAULT NULL,
  `cd_code` varchar(255) DEFAULT NULL,
  `disc_num` int(11) DEFAULT NULL,
  `disc_count` int(11) DEFAULT NULL,
  `release_year` int(11) DEFAULT NULL,
  `artist_original` varchar(255) DEFAULT NULL,
  `artist_english` varchar(255) DEFAULT NULL,
  `synopsis` text,
  `publisher_id` int(11) DEFAULT NULL,
  `live_album` tinyint(1) DEFAULT '0',
  `explicit_lyrics` tinyint(1) DEFAULT '0',
  `to_delete` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `cover_file_name` varchar(255) DEFAULT NULL,
  `cover_content_type` varchar(255) DEFAULT NULL,
  `cover_file_size` int(11) DEFAULT NULL,
  `cover_updated_at` datetime DEFAULT NULL,
  `genre` varchar(255) NOT NULL DEFAULT '',
  `musicbrainz_id` text,
  `language_id` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `origin_id` int(11) DEFAULT NULL,
  `total_duration` int(11) DEFAULT NULL,
  `tracks_count` int(11) DEFAULT '0',
  `compilation` tinyint(1) DEFAULT '0',
  `mp3_exists` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albums_genres`
--

DROP TABLE IF EXISTS `albums_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albums_genres` (
  `genre_id` int(11) DEFAULT NULL,
  `album_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums_genres`
--

LOCK TABLES `albums_genres` WRITE;
/*!40000 ALTER TABLE `albums_genres` DISABLE KEYS */;
/*!40000 ALTER TABLE `albums_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audio_playlist_tracks`
--

DROP TABLE IF EXISTS `audio_playlist_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audio_playlist_tracks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `audio_playlist_id` int(11) DEFAULT NULL,
  `track_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `mastering` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `split` varchar(255) DEFAULT NULL,
  `vo_duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_audio_playlist_tracks_on_audio_playlist_id` (`audio_playlist_id`),
  KEY `index_audio_playlist_tracks_on_track_id` (`track_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audio_playlist_tracks`
--

LOCK TABLES `audio_playlist_tracks` WRITE;
/*!40000 ALTER TABLE `audio_playlist_tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `audio_playlist_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audio_playlists`
--

DROP TABLE IF EXISTS `audio_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audio_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_playlist_code` varchar(255) DEFAULT NULL,
  `airline_id` int(11) DEFAULT NULL,
  `in_out` varchar(255) DEFAULT NULL,
  `start_playdate` date DEFAULT NULL,
  `end_playdate` date DEFAULT NULL,
  `vo_id` int(11) DEFAULT NULL,
  `mastering` text,
  `user_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `program_cache` varchar(255) DEFAULT NULL,
  `airline_cache` varchar(255) DEFAULT NULL,
  `airline_duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audio_playlists`
--

LOCK TABLES `audio_playlists` WRITE;
/*!40000 ALTER TABLE `audio_playlists` DISABLE KEYS */;
INSERT INTO `audio_playlists` VALUES (1,'321123',2,'Inbound','2013-03-01','2013-03-01',2,NULL,1,2,0,'2013-03-05 17:12:07','2013-03-05 17:12:07','Program','MAT','120'),(2,'',NULL,'','2013-03-01','2013-03-01',NULL,NULL,1,NULL,0,'2013-03-06 09:58:39','2013-03-06 09:58:39','','',''),(3,'Au914u0jd',19,'Inbound/Outbound','2013-03-01','2013-03-01',2,NULL,1,2,0,'2013-03-06 10:12:07','2013-03-06 10:12:07','Program','sadfdsf','120'),(4,'321123',2,'Inbound','2013-03-01','2013-03-01',2,NULL,1,2,0,'2013-03-06 10:13:13','2013-03-06 10:13:13','Program','MAT',NULL),(5,'321123',2,'Inbound','2013-03-01','2013-03-01',2,NULL,1,2,0,'2013-03-06 10:13:18','2013-03-08 13:00:34','Program','MAT',''),(6,'',NULL,'','2013-03-01','2013-03-01',NULL,NULL,1,NULL,0,'2013-03-07 14:49:05','2013-03-07 14:52:04','','',''),(7,'',NULL,'','2013-03-01','2013-03-01',NULL,NULL,1,NULL,0,'2013-03-08 13:14:25','2013-03-08 13:14:25','','',NULL),(8,'Au914u0jd',8,'Inbound','2013-03-01','2013-03-01',2,NULL,1,2,0,'2013-03-08 13:24:34','2013-03-08 13:24:34','Program','test','120');
/*!40000 ALTER TABLE `audio_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'','2012-12-20 17:41:04','2012-12-20 17:41:04'),(2,'Category','2013-03-01 14:58:08','2013-03-01 14:58:08');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commercial_run_times`
--

DROP TABLE IF EXISTS `commercial_run_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commercial_run_times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minutes` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commercial_run_times`
--

LOCK TABLES `commercial_run_times` WRITE;
/*!40000 ALTER TABLE `commercial_run_times` DISABLE KEYS */;
INSERT INTO `commercial_run_times` VALUES (1,120,'2013-03-05 15:53:40','2013-03-05 15:56:13'),(2,200,'2013-03-05 15:54:20','2013-03-05 15:54:20'),(3,300,'2013-03-05 15:56:04','2013-03-05 15:56:04');
/*!40000 ALTER TABLE `commercial_run_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `covers`
--

DROP TABLE IF EXISTS `covers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `covers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_covers_on_album_id_and_parent_id` (`album_id`,`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `covers`
--

LOCK TABLES `covers` WRITE;
/*!40000 ALTER TABLE `covers` DISABLE KEYS */;
/*!40000 ALTER TABLE `covers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres`
--

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;
INSERT INTO `genres` VALUES (1,'Blues','2013-03-01 18:12:03','2013-03-01 18:12:03'),(2,'Country','2013-03-01 18:12:10','2013-03-01 18:12:10'),(3,'Rock','2013-03-01 18:12:15','2013-03-01 18:12:15'),(4,'Electro','2013-03-01 18:12:20','2013-03-01 18:27:46');
/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres_tracks`
--

DROP TABLE IF EXISTS `genres_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genres_tracks` (
  `genre_id` int(11) DEFAULT NULL,
  `track_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres_tracks`
--

LOCK TABLES `genres_tracks` WRITE;
/*!40000 ALTER TABLE `genres_tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `genres_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labels`
--

DROP TABLE IF EXISTS `labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labels`
--

LOCK TABLES `labels` WRITE;
/*!40000 ALTER TABLE `labels` DISABLE KEYS */;
INSERT INTO `labels` VALUES (1,'ABC','2013-03-01 18:19:28','2013-03-01 18:19:28'),(2,'DEF','2013-03-01 18:19:30','2013-03-01 18:19:30');
/*!40000 ALTER TABLE `labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','2013-03-01 18:21:05','2013-03-01 18:21:05');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_languages`
--

DROP TABLE IF EXISTS `master_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_languages`
--

LOCK TABLES `master_languages` WRITE;
/*!40000 ALTER TABLE `master_languages` DISABLE KEYS */;
INSERT INTO `master_languages` VALUES (1,'Eng','2012-12-20 17:41:08','2012-12-20 17:41:08'),(2,'Zho','2012-12-20 17:41:08','2012-12-20 17:41:08'),(3,'Ara','2012-12-20 17:41:08','2013-03-05 16:02:17'),(4,'Cfr','2012-12-20 17:41:08','2012-12-20 17:41:08'),(5,'Dan','2012-12-20 17:41:08','2012-12-20 17:41:08'),(6,'Deu','2012-12-20 17:41:08','2012-12-20 17:41:08'),(7,'Ell','2012-12-20 17:41:08','2012-12-20 17:41:08'),(8,'Fas','2012-12-20 17:41:08','2012-12-20 17:41:08'),(9,'Fin','2012-12-20 17:41:08','2012-12-20 17:41:08'),(10,'Fra','2012-12-20 17:41:08','2012-12-20 17:41:08'),(11,'Hin','2012-12-20 17:41:08','2012-12-20 17:41:08'),(12,'Heb','2012-12-20 17:41:08','2012-12-20 17:41:08'),(13,'Ind','2012-12-20 17:41:08','2012-12-20 17:41:08'),(14,'Ita','2012-12-20 17:41:08','2012-12-20 17:41:08'),(15,'Jpn','2012-12-20 17:41:08','2012-12-20 17:41:08'),(16,'Kor','2012-12-20 17:41:08','2012-12-20 17:41:08'),(17,'Msa','2012-12-20 17:41:08','2012-12-20 17:41:08'),(18,'Nld','2012-12-20 17:41:08','2012-12-20 17:41:08'),(19,'Nor','2012-12-20 17:41:08','2012-12-20 17:41:08'),(20,'Por','2012-12-20 17:41:08','2012-12-20 17:41:08'),(21,'Rus','2012-12-20 17:41:08','2012-12-20 17:41:08'),(22,'Spa','2012-12-20 17:41:08','2012-12-20 17:41:08'),(23,'Spn','2012-12-20 17:41:08','2012-12-20 17:41:08'),(24,'Swe','2012-12-20 17:41:08','2012-12-20 17:41:08'),(25,'Tam','2012-12-20 17:41:08','2012-12-20 17:41:08'),(26,'Tgl','2012-12-20 17:41:08','2012-12-20 17:41:08'),(27,'Tha','2012-12-20 17:41:08','2012-12-20 17:41:08'),(28,'Tur','2012-12-20 17:41:08','2012-12-20 17:41:08'),(29,'Vie','2012-12-20 17:41:08','2012-12-20 17:41:08'),(31,'Yue','2013-03-05 16:02:28','2013-03-05 16:02:28');
/*!40000 ALTER TABLE `master_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_playlist_types`
--

DROP TABLE IF EXISTS `master_playlist_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_playlist_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_playlist_types`
--

LOCK TABLES `master_playlist_types` WRITE;
/*!40000 ALTER TABLE `master_playlist_types` DISABLE KEYS */;
INSERT INTO `master_playlist_types` VALUES (3,'ABC','2013-03-03 21:31:21','2013-03-03 21:31:21');
/*!40000 ALTER TABLE `master_playlist_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masters`
--

DROP TABLE IF EXISTS `masters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` int(11) DEFAULT NULL,
  `episode_title` varchar(255) DEFAULT NULL,
  `episode_number` varchar(255) DEFAULT NULL,
  `tape_media` varchar(255) DEFAULT NULL,
  `tape_format` varchar(255) DEFAULT NULL,
  `tape_size` varchar(255) DEFAULT NULL,
  `language_track_1` varchar(255) DEFAULT NULL,
  `language_track_2` varchar(255) DEFAULT NULL,
  `language_track_3` varchar(255) DEFAULT NULL,
  `language_track_4` varchar(255) DEFAULT NULL,
  `video_subtitles_1` varchar(255) DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  `time_in` varchar(255) DEFAULT NULL,
  `time_out` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `synopsis` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `aspect_ratio` varchar(255) DEFAULT NULL,
  `video_subtitles_2` varchar(255) DEFAULT NULL,
  `in_playlists` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_masters_on_video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masters`
--

LOCK TABLES `masters` WRITE;
/*!40000 ALTER TABLE `masters` DISABLE KEYS */;
/*!40000 ALTER TABLE `masters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_genres`
--

DROP TABLE IF EXISTS `movie_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_genres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_genres`
--

LOCK TABLES `movie_genres` WRITE;
/*!40000 ALTER TABLE `movie_genres` DISABLE KEYS */;
INSERT INTO `movie_genres` VALUES (1,'ABC','2013-03-03 21:39:06','2013-03-03 21:39:06'),(2,'GHI','2013-03-03 21:39:08','2013-03-03 21:39:13');
/*!40000 ALTER TABLE `movie_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_genres_movies`
--

DROP TABLE IF EXISTS `movie_genres_movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_genres_movies` (
  `movie_genre_id` int(11) DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_genres_movies`
--

LOCK TABLES `movie_genres_movies` WRITE;
/*!40000 ALTER TABLE `movie_genres_movies` DISABLE KEYS */;
/*!40000 ALTER TABLE `movie_genres_movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_playlist_items`
--

DROP TABLE IF EXISTS `movie_playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_playlist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `movie_playlist_id` int(11) DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_movie_playlist_items_on_movie_playlist_id` (`movie_playlist_id`),
  KEY `index_movie_playlist_items_on_movie_id` (`movie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_playlist_items`
--

LOCK TABLES `movie_playlist_items` WRITE;
/*!40000 ALTER TABLE `movie_playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `movie_playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_playlists`
--

DROP TABLE IF EXISTS `movie_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `airline_id` int(11) DEFAULT NULL,
  `start_cycle` date DEFAULT NULL,
  `end_cycle` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `movie_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_movie_playlists_on_airline_id` (`airline_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_playlists`
--

LOCK TABLES `movie_playlists` WRITE;
/*!40000 ALTER TABLE `movie_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `movie_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `movie_title` varchar(255) DEFAULT NULL,
  `foreign_language_title` varchar(255) DEFAULT NULL,
  `movie_type` varchar(255) DEFAULT NULL,
  `movie_distributor_id` int(11) DEFAULT NULL,
  `production_studio_id` int(11) DEFAULT NULL,
  `laboratory_id` int(11) DEFAULT NULL,
  `theatrical_release_year` int(11) DEFAULT NULL,
  `airline_release_date` date DEFAULT NULL,
  `personal_video_date` date DEFAULT NULL,
  `theatrical_runtime` int(11) DEFAULT NULL,
  `edited_runtime` int(11) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `cast` text,
  `director` varchar(255) DEFAULT NULL,
  `synopsis` text,
  `critics_review` text,
  `airline_rights` varchar(255) DEFAULT NULL,
  `screener_received_date` date DEFAULT NULL,
  `screener_destroyed_date` date DEFAULT NULL,
  `screener_remarks` varchar(255) DEFAULT NULL,
  `screener_remarks_other` varchar(255) DEFAULT NULL,
  `to_delete` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `poster_file_name` varchar(255) DEFAULT NULL,
  `poster_content_type` varchar(255) DEFAULT NULL,
  `poster_file_size` int(11) DEFAULT NULL,
  `poster_updated_at` datetime DEFAULT NULL,
  `release_versions_mask` int(11) DEFAULT NULL,
  `release_version` varchar(255) DEFAULT NULL,
  `screener_remarks_mask` int(11) DEFAULT NULL,
  `screener_remark` varchar(255) DEFAULT NULL,
  `has_press_kit` tinyint(1) DEFAULT NULL,
  `has_poster` tinyint(1) DEFAULT NULL,
  `airline_countries` text,
  `poster_quantity` int(11) DEFAULT '0',
  `remarks` text,
  `in_playlists` varchar(255) DEFAULT NULL,
  `language_tracks` text,
  `language_subtitles` text,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_movies_on_movie_distributor_id` (`movie_distributor_id`),
  KEY `index_movies_on_production_studio_id` (`production_studio_id`),
  KEY `index_movies_on_laboratory_id` (`laboratory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'BATMAN',NULL,'Hollywood Movie',NULL,NULL,NULL,2013,NULL,NULL,NULL,NULL,'NR','','','','','Worldwide',NULL,NULL,NULL,NULL,0,'2013-03-06 17:02:27','2013-03-06 17:02:27',NULL,NULL,NULL,NULL,1,NULL,0,NULL,0,0,NULL,0,'',NULL,'---\n- \'\'\n','---\n- \'\'\n',1),(2,'SUPERMAN',NULL,'Hollywood Movie',1,4,2,2013,NULL,NULL,NULL,NULL,'NR','','','','','Worldwide',NULL,NULL,NULL,NULL,0,'2013-03-06 23:06:40','2013-03-07 13:18:06',NULL,NULL,NULL,NULL,1,NULL,0,NULL,0,0,NULL,0,'',NULL,'---\n- \'\'\n','---\n- \'\'\n',1),(3,'DANCER IN THE DARK',NULL,'Danish Movie',1,4,2,2013,NULL,NULL,NULL,NULL,'NR','','','','','Worldwide',NULL,NULL,NULL,NULL,0,'2013-03-07 15:19:11','2013-03-07 15:19:11',NULL,NULL,NULL,NULL,1,NULL,0,NULL,0,0,NULL,0,'',NULL,'---\n- \'\'\n- Eng\n','---\n- \'\'\n- Eng\n',1);
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `origins`
--

DROP TABLE IF EXISTS `origins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `origins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `origins`
--

LOCK TABLES `origins` WRITE;
/*!40000 ALTER TABLE `origins` DISABLE KEYS */;
INSERT INTO `origins` VALUES (1,'qwerty','2013-03-01 18:21:27','2013-03-01 18:21:27');
/*!40000 ALTER TABLE `origins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (2,'Program','2013-02-25 13:48:25','2013-03-01 14:39:12');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publishers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishers`
--

LOCK TABLES `publishers` WRITE;
/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` VALUES (1,'ABC','2013-03-01 18:19:53','2013-03-01 18:19:53'),(3,'DEFdasdas','2013-03-01 18:20:03','2013-03-01 18:20:57');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights`
--

DROP TABLE IF EXISTS `rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights`
--

LOCK TABLES `rights` WRITE;
/*!40000 ALTER TABLE `rights` DISABLE KEYS */;
/*!40000 ALTER TABLE `rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights_roles`
--

DROP TABLE IF EXISTS `rights_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rights_roles` (
  `right_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights_roles`
--

LOCK TABLES `rights_roles` WRITE;
/*!40000 ALTER TABLE `rights_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `rights_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'administrator'),(2,'programmer'),(3,'video_programmer'),(4,'client');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `role_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20080720150337'),('20080720150515'),('20080720150652'),('20080721171328'),('20080726124034'),('20080727095952'),('20080728094029'),('20080806134447'),('20080807170333'),('20080807171458'),('20080810062138'),('20080810073218'),('20080810074506'),('20080810074536'),('20080912183625'),('20080912184031'),('20081030171115'),('20081030174159'),('20081101172003'),('20081122062025'),('20090104071115'),('20090105174754'),('20090105175827'),('20090105175828'),('20090111180804'),('20090112115403'),('20090126155745'),('20090131174839'),('20090201182340'),('20090202083609'),('20090206100256'),('20090210083459'),('20090212061952'),('20090309200723'),('20090319162009'),('20090321162540'),('20090407180909'),('20091104083737'),('20091104091018'),('20091107185209'),('20091108054232'),('20091108061802'),('20091108093509'),('20091127163932'),('20091128005555'),('20091128024548'),('20091128150904'),('20091128164018'),('20091130140205'),('20091215132829'),('20091227074555'),('20091227082435'),('20091227090954'),('20091227130219'),('20091227154951'),('20100213225945'),('20100220162343'),('20100328154107'),('20100410023155'),('20100410070201'),('20100411025311'),('20100411030625'),('20100609104419'),('20100609105724'),('20100617105850'),('20100617110011'),('20100628103117'),('20100704101557'),('20100705220827'),('20100710043539'),('20100710044445'),('20100808162442'),('20100809031608'),('20100818034957'),('20100905175411'),('20100908020757'),('20100921055102'),('20100922095343'),('20100922095355'),('20100922104457'),('20100922131251'),('20101011153519'),('20101011155729'),('20101106144922'),('20101214173130'),('20101221065500'),('20110928050648'),('20110929060612');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screener_playlist_items`
--

DROP TABLE IF EXISTS `screener_playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `screener_playlist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `screener_playlist_id` int(11) DEFAULT NULL,
  `screener_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `mastering` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_screener_playlist_items_on_screener_playlist_id` (`screener_playlist_id`),
  KEY `index_screener_playlist_items_on_screener_id` (`screener_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screener_playlist_items`
--

LOCK TABLES `screener_playlist_items` WRITE;
/*!40000 ALTER TABLE `screener_playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `screener_playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screener_playlists`
--

DROP TABLE IF EXISTS `screener_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `screener_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `airline_id` int(11) DEFAULT NULL,
  `start_cycle` date DEFAULT NULL,
  `end_cycle` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_runtime` varchar(255) DEFAULT NULL,
  `edit_runtime` varchar(255) DEFAULT NULL,
  `media_instruction` text,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `video_playlist_type_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_screener_playlists_on_airline_id` (`airline_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screener_playlists`
--

LOCK TABLES `screener_playlists` WRITE;
/*!40000 ALTER TABLE `screener_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `screener_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screeners`
--

DROP TABLE IF EXISTS `screeners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `screeners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` int(11) DEFAULT NULL,
  `episode_title` varchar(255) DEFAULT NULL,
  `episode_number` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `remarks_other` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `in_playlists` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_screeners_on_video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screeners`
--

LOCK TABLES `screeners` WRITE;
/*!40000 ALTER TABLE `screeners` DISABLE KEYS */;
/*!40000 ALTER TABLE `screeners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `splits`
--

DROP TABLE IF EXISTS `splits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `splits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `more_than` int(11) DEFAULT NULL,
  `less_than` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `splits`
--

LOCK TABLES `splits` WRITE;
/*!40000 ALTER TABLE `splits` DISABLE KEYS */;
INSERT INTO `splits` VALUES (1,'120 min','120',7320000,7440000,'2013-03-01 18:22:53','2013-03-01 18:22:53');
/*!40000 ALTER TABLE `splits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_categories`
--

DROP TABLE IF EXISTS `supplier_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_categories`
--

LOCK TABLES `supplier_categories` WRITE;
/*!40000 ALTER TABLE `supplier_categories` DISABLE KEYS */;
INSERT INTO `supplier_categories` VALUES (1,'Video Distributors','-','2012-12-20 17:41:20','2012-12-20 17:41:20'),(2,'Movie Distributors','-','2012-12-20 17:41:20','2012-12-20 17:41:20'),(3,'Laboratories','-','2012-12-20 17:41:20','2012-12-20 17:41:20'),(4,'Production Studios','-','2012-12-20 17:41:20','2012-12-20 17:41:20'),(5,'Advertising & Gifts','-','2013-03-05 14:01:39','2013-03-05 14:01:39'),(6,'Something Bogus','Not Real','2013-03-05 14:01:56','2013-03-05 14:01:56');
/*!40000 ALTER TABLE `supplier_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_categories_suppliers`
--

DROP TABLE IF EXISTS `supplier_categories_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_categories_suppliers` (
  `supplier_id` int(11) DEFAULT NULL,
  `supplier_category_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_categories_suppliers`
--

LOCK TABLES `supplier_categories_suppliers` WRITE;
/*!40000 ALTER TABLE `supplier_categories_suppliers` DISABLE KEYS */;
INSERT INTO `supplier_categories_suppliers` VALUES (1,1,NULL,NULL),(1,2,NULL,NULL),(2,1,NULL,NULL),(2,3,NULL,NULL),(4,1,NULL,NULL),(4,4,NULL,NULL);
/*!40000 ALTER TABLE `supplier_categories_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL,
  `contact_name_1` varchar(255) DEFAULT NULL,
  `position_1` varchar(255) DEFAULT NULL,
  `tel_1` varchar(255) DEFAULT NULL,
  `fax_1` varchar(255) DEFAULT NULL,
  `hp_1` varchar(255) DEFAULT NULL,
  `email_1` varchar(255) DEFAULT NULL,
  `contact_name_2` varchar(255) DEFAULT NULL,
  `position_2` varchar(255) DEFAULT NULL,
  `tel_2` varchar(255) DEFAULT NULL,
  `fax_2` varchar(255) DEFAULT NULL,
  `hp_2` varchar(255) DEFAULT NULL,
  `email_2` varchar(255) DEFAULT NULL,
  `address` text,
  `website` varchar(255) DEFAULT NULL,
  `remarks` text,
  `bank` varchar(255) DEFAULT NULL,
  `bank_branch` text,
  `bank_account` varchar(255) DEFAULT NULL,
  `aba_routing` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `beneficiary_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'Emphasis Video Entertainment Limited','','','','','','','','','','','','','','','','','','','','2013-03-05 12:53:27','2013-03-05 12:53:27',''),(2,'EROS International Media Pvt Ltd.','','','','','','','','','','','','','','','','','','','','2013-03-05 13:21:32','2013-03-05 13:21:32',''),(4,'AV-Jet International Media Co., Ltd','','','','','','','','','','','','','','','','','','','','2013-03-05 13:34:17','2013-03-05 13:34:17','');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tempos`
--

DROP TABLE IF EXISTS `tempos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempos`
--

LOCK TABLES `tempos` WRITE;
/*!40000 ALTER TABLE `tempos` DISABLE KEYS */;
INSERT INTO `tempos` VALUES (1,'S','2012-12-20 17:41:04','2012-12-20 17:41:04'),(2,'SM','2012-12-20 17:41:04','2012-12-20 17:41:04'),(3,'M','2012-12-20 17:41:04','2012-12-20 17:41:04'),(4,'MS','2012-12-20 17:41:04','2012-12-20 17:41:04'),(5,'MF','2012-12-20 17:41:04','2012-12-20 17:41:04'),(6,'F','2012-12-20 17:41:04','2012-12-20 17:41:04'),(7,'VF','2012-12-20 17:41:04','2012-12-20 17:41:04');
/*!40000 ALTER TABLE `tempos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracks`
--

DROP TABLE IF EXISTS `tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tracks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) DEFAULT NULL,
  `title_english` varchar(255) DEFAULT NULL,
  `title_original` varchar(255) DEFAULT NULL,
  `artist_english` varchar(255) DEFAULT NULL,
  `artist_original` varchar(255) DEFAULT NULL,
  `composer` varchar(255) DEFAULT NULL,
  `distributor` varchar(255) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `ending` varchar(255) DEFAULT NULL,
  `tempo_intro` varchar(255) DEFAULT NULL,
  `tempo_outro` varchar(255) DEFAULT NULL,
  `tempo` varchar(255) DEFAULT NULL,
  `track_num` int(11) DEFAULT NULL,
  `lyrics` text,
  `language_id` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `origin_id` int(11) DEFAULT NULL,
  `to_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `genre` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `genres` text,
  `musicbrainz_id` text,
  `explicit_lyrics` tinyint(1) DEFAULT '0',
  `mp3_exists` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_tracks_on_album_id` (`album_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracks`
--

LOCK TABLES `tracks` WRITE;
/*!40000 ALTER TABLE `tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `crypted_password` varchar(255) DEFAULT NULL,
  `password_salt` varchar(255) DEFAULT NULL,
  `persistence_token` varchar(255) DEFAULT NULL,
  `login_count` int(11) DEFAULT NULL,
  `last_request_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `current_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(255) DEFAULT NULL,
  `current_login_ip` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `perishable_token` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `roles` text,
  PRIMARY KEY (`id`),
  KEY `index_users_on_perishable_token` (`perishable_token`),
  KEY `index_users_on_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'mat2maa','$2a$10$HeQ3B1qYmlPEcF1lZMstpedcWbrvvPKleMQzPyigofwubbQCfdWTm','obSYyp0HdXeuy0kgkvyq','2c71eed8fbbe8ddf697eaa8782996fa4464665fff343356b7b1ecdd2b19638f2ad05f425dddcdbc406888cbbee12e60d692e4853e80fb03e3fed48b5b5a45359',11,'2013-03-11 15:01:19','2013-03-02 09:24:19','2013-03-02 11:04:19','127.0.0.1','127.0.0.1',1,'2012-12-20 18:03:42','2013-03-11 15:01:19','5pS2p47UCfTZZFbocfd','matthew.a.ager@googlemail.com','---\n- administrator\n'),(2,'ognen','$2a$10$y5O63GzwT0ALsN50w9Lf3OHa.qpebZIsy0UCgytoN4C2cGqXI2u2y','WxZIPwLZmvaScWvnXFlZ','0c2b86fb628b0e67e115589ccb59652af86e615ce99e82e00f6f4bd5dbcfa887aca25094dde8ad18b12fc8dd4c0780bbc704c80ab2809e4f8d7206b63705411e',NULL,NULL,NULL,NULL,NULL,NULL,1,'2013-02-28 17:34:18','2013-03-02 09:26:13','9cVxAR2f4oTY2pGVcs','ognen.ivanovski@gmail.com','---\n- administrator\n'),(3,'test','$2a$10$ggk9GRkgEwlPgOn4Va.aAec63VDqUGtFTRhDHdJL4YnPRsCnM2oTe','vizBrQZtn8HZyMGltaAu','5097aab93fa187d1ee40f7e4b3eaee3405c7ffe8ac096fb59b40c7a0c110ca764b627439fe63e1182fde6383f303c43a852a1f24fcc7ad7637b306f5f9bdadf5',2,'2013-03-02 11:04:10','2013-03-02 11:03:57','2013-03-02 11:04:07','127.0.0.1','127.0.0.1',1,'2013-03-02 09:22:18','2013-03-02 11:04:10','EJLmYHZEb6OY5EcNLFsX','matthew.a.ager@gmail.com','---\n- administrator\n');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_genres`
--

DROP TABLE IF EXISTS `video_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_genres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `video_parent_genre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_video_genres_on_video_parent_genre_id` (`video_parent_genre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_genres`
--

LOCK TABLES `video_genres` WRITE;
/*!40000 ALTER TABLE `video_genres` DISABLE KEYS */;
INSERT INTO `video_genres` VALUES (1,'ABC','2013-03-05 10:29:58','2013-03-05 10:29:58',NULL),(2,'DEF','2013-03-05 10:40:24','2013-03-05 10:40:24',3);
/*!40000 ALTER TABLE `video_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_genres_videos`
--

DROP TABLE IF EXISTS `video_genres_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_genres_videos` (
  `video_genre_id` int(11) DEFAULT NULL,
  `video_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_genres_videos`
--

LOCK TABLES `video_genres_videos` WRITE;
/*!40000 ALTER TABLE `video_genres_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_genres_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_master_playlist_items`
--

DROP TABLE IF EXISTS `video_master_playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_master_playlist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_master_playlist_id` int(11) DEFAULT NULL,
  `master_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `mastering` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_video_master_playlist_items_on_video_master_playlist_id` (`video_master_playlist_id`),
  KEY `index_video_master_playlist_items_on_master_id` (`master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_master_playlist_items`
--

LOCK TABLES `video_master_playlist_items` WRITE;
/*!40000 ALTER TABLE `video_master_playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_master_playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_master_playlists`
--

DROP TABLE IF EXISTS `video_master_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_master_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `airline_id` int(11) DEFAULT NULL,
  `start_cycle` date DEFAULT NULL,
  `end_cycle` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `total_runtime` varchar(255) DEFAULT NULL,
  `edit_runtime` varchar(255) DEFAULT NULL,
  `media_instruction` text,
  `master_playlist_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_video_master_playlists_on_airline_id` (`airline_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_master_playlists`
--

LOCK TABLES `video_master_playlists` WRITE;
/*!40000 ALTER TABLE `video_master_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_master_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_parent_genres`
--

DROP TABLE IF EXISTS `video_parent_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_parent_genres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_parent_genres`
--

LOCK TABLES `video_parent_genres` WRITE;
/*!40000 ALTER TABLE `video_parent_genres` DISABLE KEYS */;
INSERT INTO `video_parent_genres` VALUES (1,'ABC','2013-03-05 10:39:49','2013-03-05 10:39:49'),(3,'DEF','2013-03-05 10:40:10','2013-03-05 10:40:10');
/*!40000 ALTER TABLE `video_parent_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_playlist_items`
--

DROP TABLE IF EXISTS `video_playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_playlist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_playlist_id` int(11) DEFAULT NULL,
  `video_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_video_playlist_items_on_video_playlist_id` (`video_playlist_id`),
  KEY `index_video_playlist_items_on_video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_playlist_items`
--

LOCK TABLES `video_playlist_items` WRITE;
/*!40000 ALTER TABLE `video_playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_playlist_types`
--

DROP TABLE IF EXISTS `video_playlist_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_playlist_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_playlist_types`
--

LOCK TABLES `video_playlist_types` WRITE;
/*!40000 ALTER TABLE `video_playlist_types` DISABLE KEYS */;
INSERT INTO `video_playlist_types` VALUES (1,'ABC','2013-03-02 11:10:22','2013-03-02 11:11:59'),(2,'DEF','2013-03-02 11:10:26','2013-03-02 11:10:26'),(3,'GHI','2013-03-02 11:10:30','2013-03-02 11:10:30');
/*!40000 ALTER TABLE `video_playlist_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_playlists`
--

DROP TABLE IF EXISTS `video_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `airline_id` int(11) DEFAULT NULL,
  `start_cycle` date DEFAULT NULL,
  `end_cycle` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `video_playlist_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_video_playlists_on_airline_id` (`airline_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_playlists`
--

LOCK TABLES `video_playlists` WRITE;
/*!40000 ALTER TABLE `video_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `programme_title` varchar(255) DEFAULT NULL,
  `foreign_language_title` varchar(255) DEFAULT NULL,
  `video_type` varchar(255) DEFAULT NULL,
  `production_studio_id` int(11) DEFAULT NULL,
  `laboratory_id` int(11) DEFAULT NULL,
  `production_year` int(11) DEFAULT NULL,
  `episodes_available` int(11) DEFAULT NULL,
  `synopsis` text,
  `trailer_url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `poster_file_name` varchar(255) DEFAULT NULL,
  `poster_content_type` varchar(255) DEFAULT NULL,
  `poster_file_size` int(11) DEFAULT NULL,
  `poster_updated_at` datetime DEFAULT NULL,
  `to_delete` tinyint(1) DEFAULT '0',
  `commercial_run_time_id` int(11) DEFAULT NULL,
  `video_distributor_id` int(11) DEFAULT NULL,
  `on_going_series` tinyint(1) DEFAULT NULL,
  `remarks` text,
  `masters_count` int(11) DEFAULT '0',
  `screeners_count` int(11) DEFAULT '0',
  `in_playlists` varchar(255) DEFAULT NULL,
  `language_tracks` text,
  `language_subtitles` text,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_videos_on_video_type` (`video_type`),
  KEY `index_videos_on_production_studio_id` (`production_studio_id`),
  KEY `index_videos_on_laboratory_id` (`laboratory_id`),
  KEY `index_videos_on_video_distributor_id` (`video_distributor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vo_durations`
--

DROP TABLE IF EXISTS `vo_durations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vo_durations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vo_durations`
--

LOCK TABLES `vo_durations` WRITE;
/*!40000 ALTER TABLE `vo_durations` DISABLE KEYS */;
INSERT INTO `vo_durations` VALUES (1,'Something','240','2013-03-01 18:24:20','2013-03-01 18:24:20'),(2,'Something Else','400','2013-03-01 18:24:36','2013-03-01 18:24:36');
/*!40000 ALTER TABLE `vo_durations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vos`
--

DROP TABLE IF EXISTS `vos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vos`
--

LOCK TABLES `vos` WRITE;
/*!40000 ALTER TABLE `vos` DISABLE KEYS */;
INSERT INTO `vos` VALUES (2,'mnb','2013-03-01 18:22:05','2013-03-01 18:22:11');
/*!40000 ALTER TABLE `vos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-03-11 17:13:40
